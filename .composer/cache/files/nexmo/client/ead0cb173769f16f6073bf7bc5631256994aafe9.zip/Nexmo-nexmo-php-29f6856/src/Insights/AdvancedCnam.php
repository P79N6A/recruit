<?php
namespace Nexmo\Insights;

class AdvancedCnam extends Advanced
{
    use CnamTrait;
}